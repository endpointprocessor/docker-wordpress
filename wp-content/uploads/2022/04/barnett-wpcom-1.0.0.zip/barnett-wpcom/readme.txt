=== Barnett ===
Contributors: Automattic
Requires at least: 5.8
Tested up to: 5.8
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Barnett is a minimalist theme, designed for single-page websites.

== Changelog ==

= 20 January 2022 =
* D73473
* Add Headstart annotation file.
* Add POT file.
* Add Barnett theme to the public themes directory.

== Copyright ==

Barnett WordPress Theme, (C) 2021 Automattic
Barnett is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Barnett uses the following third-party resources:

Green tropical leaves background. Original public domain image from Wikimedia Commons.
Source: https://www.rawpixel.com/image/3286299/free-photo-image-flower-tropical-green
Used in theme screenshot and demo site.